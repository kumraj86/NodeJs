const express=require("express");
const { json } = require("express");

const app=express();
// var _bodyParserPackage = require("body-parser");  
// app.use(_bodyParserPackage.json());
// //Here we will enable CORS, so that we can access api on cross domain.  
// app.use(function (req, res, next) {  
//     res.header("Access-Control-Allow-Origin", "*");  
//     res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");  
//     res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, contentType,Content-Type, Accept, Authorization");  
//     next();  
// })

var cors = require('cors')
app.use(cors());

var BAL_Student=require("../Demo/StudentM/BAL")

app.post('/student/DeleteStudent', function(req,res)
{
  BAL_Student.DeleteStudent(req, res, function (data,err) {
    res.send(data);
  }); 
});

app.post('/student/SaveStudent', function(req,res)
{
  BAL_Student.SaveStudent(req, res, function (data,err) {
    res.send(data);
  }); 
});

app.get('/student/GetStudent', function(req,res)
{
  BAL_Student.GetStudent(req, res, function (data,err) {
    res.send(data);
  }); 
});

app.post('/student/GetStudentDetails', function(req,res)
{  
  BAL_Student.GetStudentDetails(req, res,function (data,err) {
    res.send(data);
  }); 
});

const webserver=app.listen(5001,function(){
  console.log("Hello");
})

