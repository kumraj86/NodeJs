var DAL=require("../StudentM/DAL")

exports.DeleteStudent = function (req, res, callback1){ 
    var reqBody="";
    req.on("data",function(data) {
        reqBody+=data;
    });
    req.on("end",function(data) {
        DAL.DeleteStudent(reqBody,function(data,err)
        {
            callback1(data);
        });
    });       
}


exports.SaveStudent = function (req, res, callback1){ 
    var reqBody="";
    req.on("data",function(data) {
        reqBody+=data;
    });
    req.on("end",function(data) {
        DAL.SaveStudent(reqBody,function(data,err)
        {
            callback1(data);
        });
    });        
}



exports.GetStudent = function (req, res, callback1){ 
    DAL.GetStudent(function(data,err)
    {
        callback1(data);
    });     
}


exports.GetStudentDetails = function (req, res, callback1){     
    
    var reqBody="";
    req.on("data",function(data) {
        reqBody+=data;
    });
    req.on("end",function(data) {
        DAL.GetStudentDetails(reqBody,function(data,err)
        {
            callback1(data);
        });
    });
         
}