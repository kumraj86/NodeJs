const { json } = require('express');
var Connection = require('tedious').Connection,
    Request = require('tedious').Request,
    TYPES = require('tedious').TYPES;

var config={
    server: 'localhost',
    authentication: {
        type: 'default',
        options: {
            userName: 'sa',
            password: 'admin@123'
        }
    },
    options: {
        encrypt: false,
        database: 'Test'
    }
}

exports.DeleteStudent = function (reqBody,callback) {   
    var connection = new Connection(config);
    connection.on('connect', function (err) {
        var request = new Request('USP_StudentMaster',
            function (err) {
                if (err) {
                    console.log(err);
                }
                connection.close();
            });
        console.log("Connection Successful !");
        var inputData=JSON.parse(reqBody); 

        request.addParameter('commandType', TYPES.VarChar, "D");
        request.addParameter('StudentId', TYPES.Int, inputData.StudentId);
        request.addOutputParameter('ResultCode', TYPES.VarChar);
        connection.callProcedure(request);

        request.on('returnValue', function (paramName, value, metadata) {
            callback(paramName + ' : ' + value);
        });
       
    });
}

exports.SaveStudent = function (reqBody,callback) {   
    var connection = new Connection(config);
    connection.on('connect', function (err) {
        var request = new Request('USP_StudentMaster',
            function (err) {
                if (err) {
                    console.log(err);
                }
                connection.close();
            });
        console.log("Connection Successful !");
        var inputData=JSON.parse(reqBody); 

        request.addParameter('StudentId', TYPES.Int, inputData.StudentId);
        request.addParameter('FirstName', TYPES.VarChar, inputData.FirstName);
        request.addParameter('LastName', TYPES.VarChar, inputData.LastName);
        request.addParameter('EmailId', TYPES.VarChar, inputData.EmailId);
        request.addParameter('Age', TYPES.Int, inputData.Age);
        request.addParameter('commandType', TYPES.VarChar, inputData.commandType);
        request.addOutputParameter('ResultCode', TYPES.VarChar);
        connection.callProcedure(request);

        request.on('returnValue', function (paramName, value, metadata) {
            callback(paramName + ' : ' + value);
        });       

       
    });
}

exports.GetStudent = function (callback) {   
    var connection = new Connection(config);
    connection.on('connect', function (err) {
        var request = new Request('USP_StudentMaster',
            function (err) {
                if (err) {
                    console.log(err);
                }
                connection.close();
            });
        console.log("Connection Successful !");

        request.addParameter('commandType', TYPES.VarChar, "Get");
        request.addOutputParameter('ResultCode', TYPES.VarChar);
        connection.callProcedure(request);

        request.on('returnValue', function (paramName, value, metadata) {
            console.log(paramName + ' : ' + value);
        });

        var result = "";
        var ArrayLst = new Array();
        request.on('row', function (columns) {
            var obj = new Object();
            columns.forEach(function (column) {
                result += column.value + " ";
                obj[column.metadata.colName] = column.value;
            });
            ArrayLst.push(obj);
            result = "";
        });

        request.on('doneProc', function (rowCount, more, rows) {
            //console.log(JSON.stringify(ArrayLst));
            callback(JSON.stringify(ArrayLst));
        });

       
    });
}

exports.GetStudentDetails = function (reqBody,callback) {   
    var connection = new Connection(config);
    connection.on('connect', function (err) {
        var request = new Request('USP_StudentMaster',
            function (err) {
                if (err) {
                    console.log(err);
                }
                connection.close();
            });
        console.log("Connection Successful !");


        var inputData=JSON.parse(reqBody); 
        request.addParameter('StudentId', TYPES.Int,inputData.StudentId);
        request.addParameter('commandType', TYPES.VarChar, "Get");        
        request.addOutputParameter('ResultCode', TYPES.VarChar);
        connection.callProcedure(request);


        request.on('returnValue', function (paramName, value, metadata) {
            console.log(paramName + ' : ' + value);
        });

        var result = "";
        var ArrayLst = new Array();
        request.on('row', function (columns) {
            var obj = new Object();
            columns.forEach(function (column) {
                result += column.value + " ";
                obj[column.metadata.colName] = column.value;
            });
            ArrayLst.push(obj);
            result = "";
        });

        request.on('doneProc', function (rowCount, more, rows) {
            //console.log(JSON.stringify(ArrayLst));
            callback(JSON.stringify(ArrayLst));
        });

       
    });
}